This is a special build of And Yet It Moves for PC and Mac that 
features a bonus level from the Wii Ware version of the game.

The build contains the 'Elevator' bonus level and is an exclusive 
download for the online advent calendar 'Mission in Snowdriftland - 
Indie Games Edition' of the year 2010.

http://www.mission-in-snowdriftland.com/

And Yet It Moves is a game by Broken Rules available for Windows, Mac and Linux.

http://www.andyetitmoves.com/
http://www.brokenrul.es/

We wish you all a merry christmas and a happy new year!

The Broken Rules team