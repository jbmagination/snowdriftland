Congratulations you have won the original Max & the Magic Marker prototype created in the spring of 2008. It has never been released to the public before and is only available through the Mission in Snowdriftland christmas calendar 2010.

We hope you enjoy the prototype. Please keep in mind that this edition was never meant to be released and that it may have various bugs. If you like the game and have not played the final edition, then head over to:

WWW.MAXANDTHEMAGICMARKER.COM

There you will find a free demo and a shop where you can support us indie developers by buying the full game. You can also buy the game on WiiWare.

Love,
Press Play

(support@maxandthemagicmarker.com)


//////////////////////////////////

Instructions PC:

Run the "Play Max Prototype.bat" in the "PC" folder.

//////////////////////////////////

Instructions Mac:

Run the "Play Max Prototype.html" in the "Mac" folder.

//////////////////////////////////

Max & the Magic Marker is copyright 2008-2010 Press Play Aps. 
The included content is only for personal use and may not be distributed without written permission from Press Play Aps.
